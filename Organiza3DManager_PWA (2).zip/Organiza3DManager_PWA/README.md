# Organiza 3D Manager — PWA

Aplicativo web progressivo para uso interno da Organiza 3D Home e Kids.

## Recursos desta versão

- Dashboard com faturamento, despesas, lucro, produção e falhas.
- Impressoras e investimentos.
- Matérias-primas e alertas de estoque mínimo.
- Produtos acabados.
- Produção por lotes com custo congelado.
- Registro de falhas como despesa.
- Encomendas, prazos, pagamentos e saldos.
- Movimentações financeiras.
- Backup e restauração em JSON.
- Funcionamento offline após o primeiro acesso.
- Instalação na tela inicial do iPhone/iPad.

## Como testar no computador

O PWA precisa ser servido por HTTP/HTTPS. Na pasta do projeto, execute:

```bash
python3 -m http.server 8080
```

Abra `http://localhost:8080`.

## Como colocar no iPhone/iPad

Publique a pasta em um serviço com HTTPS, como GitHub Pages, Netlify, Vercel ou hospedagem própria. Depois:

1. Abra o endereço no Safari.
2. Toque em Compartilhar.
3. Toque em “Adicionar à Tela de Início”.
4. Abra pelo ícone Organiza 3D.

Os dados ficam no armazenamento local do aparelho. Use “Configurações e backup” para exportar cópias de segurança regularmente.
